import subprocess
import time
import sys
import logging
import psutil
import uiautomation as auto
import pyautogui
import pygetwindow as gw

# Configure logging
logging.basicConfig(filename="Runtime Error.log", level=logging.INFO,
                    format="%(asctime)s - %(message)s")

# Optimize pyautogui for faster execution
pyautogui.PAUSE = 0


def get_window_by_title(title):
    """Get window object by partial title match using pygetwindow."""
    try:
        windows = gw.getWindowsWithTitle(title)
        for window in windows:
            if title in window.title:
                return window
    except Exception as e:
        logging.error(f"Error finding window: {str(e)}")
    return None


def kill_existing_fidelio_processes():
    """Terminate any running instances of Fidelio Suite 8."""
    for proc in psutil.process_iter(['pid', 'name']):
        if proc.info['name'] and proc.info['name'].lower() == 'fideliov8.exe':
            proc.terminate()
            proc.wait()
            logging.info("Existing fideliov8.exe process terminated.")
            print("Existing fideliov8.exe process terminated.")


def list_open_windows():
    """List all open window names for debugging."""
    root = auto.GetRootControl()
    print("Listing all open windows:")
    for child in root.GetChildren():
        # Log only if a name exists
        if child.Name:
            print(child.Name)


def get_top_windows():
    """Get a list of top-level windows using UI Automation."""
    root = auto.GetRootControl()
    return [control for control in root.GetChildren() if control.ControlTypeName == 'WindowControl']


def handle_error_dialogs(main_window, timeout=5):
    """
    Handle any error dialogs that appear after login.
    Prints explicit messages indicating whether error dialogs were found and dismissed.
    """
    start_time = time.time()
    error_count = 0

    while time.time() - start_time < timeout:
        try:
            error_windows = get_top_windows()
            for window in error_windows:
                # Look for windows with "Oracle Hospitality Suite8" in the name that are not the main window.
                if window.Name and "Oracle Hospitality Suite8" in window.Name:
                    if window != main_window:
                        try:
                            ok_button = window.ButtonControl(Name="OK")
                            if ok_button.Exists(0, 0):
                                print(f"Found and dismissing error dialog: {window.Name}")
                                logging.info(f"Dismissing error dialog: {window.Name}")
                                ok_button.Click()
                                error_count += 1
                                time.sleep(0.2)
                                continue

                            # If no OK button, try focusing and sending ENTER.
                            window.SetFocus()
                            window.SendKeys("{ENTER}")
                            print(f"Found and dismissed error dialog by sending ENTER: {window.Name}")
                            error_count += 1
                            time.sleep(0.2)
                        except Exception as e:
                            print(f"Error handling dialog: {str(e)}")
        except Exception as e:
            print(f"Error in dialog detection: {str(e)}")

        # If only one window with "Oracle Hospitality Suite8" remains, assume error dialogs are cleared.
        if len([w for w in get_top_windows() if w.Name and "Oracle Hospitality Suite8" in w.Name]) == 1:
            break

        time.sleep(0.2)

    if error_count > 0:
        print(f"Handled {error_count} error dialog(s)")
        logging.info(f"Successfully dismissed {error_count} error dialog(s)")
    else:
        print("No error dialogs detected")
        logging.info("No error dialogs detected")
    return error_count


def launch_fidelio_with_config(executable_path, config_file_path, username, password):
    """Launch Fidelio Suite 8 with the provided configuration."""
    try:
        kill_existing_fidelio_processes()
        time.sleep(0.5)

        subprocess.Popen([executable_path, config_file_path])
        logging.info("Fidelio application launched.")
        print("Fidelio application launched.")

        timeout = 50
        start_time = time.time()
        login_window = None

        # Wait for the login window to appear
        while time.time() - start_time < timeout:
            window = auto.WindowControl(Name="Oracle Hospitality Suite8 Login")
            if window.Exists(0, 0):
                login_window = window
                elapsed_time = time.time() - start_time
                logging.info(f"Login window detected after {elapsed_time:.2f} seconds.")
                print(f"Login window detected after {elapsed_time:.2f} seconds.")
                break
            time.sleep(0.2)

        if not login_window:
            print("Login window not found. Exiting.")
            logging.error("Login window not found.")
            sys.exit(1)

        login_window.SetFocus()
        time.sleep(0.5)

        # Enter credentials and press Enter
        pyautogui.write(username, interval=0.01)
        pyautogui.press('tab')
        pyautogui.write(password, interval=0.01)
        pyautogui.press('enter')
        print("Credentials entered and Enter key pressed.")

        time.sleep(5)  # Allow time for the application to process the login

        # For debugging, list all open windows
        list_open_windows()

        # Search for the main application window using UI Automation
        main_window = None
        retry_count = 0
        while retry_count < 1:
            main_window = auto.WindowControl(searchDepth=1, Name="Oracle Hospitality Suite8", SubName=True)
            if main_window.Exists(0, 0):
                break
            time.sleep(1)
            retry_count += 1

        # Backup method: try finding the window using pygetwindow if UI Automation did not detect it
        main_window_gw = None
        if not main_window.Exists(0, 0):
            print("Trying alternative method to find the main window...")
            main_window_gw = get_window_by_title("Oracle Hospitality Suite8")
            if main_window_gw:
                print(f"Main window found: {main_window_gw.title}")
                logging.info(f"Main window found: {main_window_gw.title}")
            else:
                logging.error("Main application window not found after login.")
                print("Error: Main application window not found after login.")
                sys.exit(1)

        # Activate the main window
        if main_window.Exists(0, 0):
            main_window.SetFocus()
            main_window.Maximize()
            print("Main application window detected and activated.")
        elif main_window_gw:
            print("Activating the window using pygetwindow...")
            main_window_gw.activate()
            time.sleep(1)
            # Click on the window to bring it into focus
            pyautogui.click(main_window_gw.left + 1, main_window_gw.top + 50)
            time.sleep(1)
            print("Main application window activated.")
            logging.info("Main application window activated.")
        else:
            logging.error("Main application window detected but not active.")
            print("Error: Main application window detected but not active.")
            sys.exit(1)

        # Determine a UI Automation element for error-checking.
        # If we got the window via pygetwindow, convert it to a UI Automation control.
        if main_window.Exists(0, 0):
            ui_main_window = main_window
        elif main_window_gw:
            try:
                ui_main_window = auto.ControlFromHandle(main_window_gw._hWnd)
            except Exception as e:
                logging.error(f"Error converting window handle to UI Automation control: {str(e)}")
                ui_main_window = None
        else:
            ui_main_window = None

        # Run error dialog checking if we have a UI Automation main window.
        if ui_main_window:
            print("Checking for error dialogs...")
            handle_error_dialogs(ui_main_window)
        else:
            print("No UI Automation main window available for error checking.")

        # Send key combination Left Alt + I + R
        pyautogui.hotkey('altleft', 'i', 'r')
        print("Sent key combination Left Alt + I + R")

        # Wait for the interface to be ready
        time.sleep(2)

        # Click a specific area relative to the window using the backup method
        if main_window_gw:
            x_offset = 1228 - main_window_gw.left
            y_offset = 97 - main_window_gw.top
            pyautogui.moveTo(main_window_gw.left + x_offset, main_window_gw.top + y_offset)
            pyautogui.click()
            time.sleep(0.2)
            print("Successfully clicked target area and entered text")
        else:
            logging.error("Could not find main window for relative positioning")
            print("Error: Could not find main window for relative positioning")
            sys.exit(1)

    except Exception as e:
        logging.error(f"Error: {str(e)}")
        print(f"Error: {str(e)}")
        sys.exit(1)


def launch_fidelio():
    """
    Launch Fidelio with default hardcoded configuration.
    This maintains backward compatibility with existing code.
    """
    # Default credentials
    executable_path = r"C:\FIDELIO\Programs\fideliov8.exe"
    config_file_path = r"C:\FIDELIO\v8whitebeach-hrg.ini"
    username = "a.ibrahim"
    password = "Des100"

    launch_fidelio_with_config(executable_path, config_file_path, username, password)


if __name__ == "__main__":
    launch_fidelio()