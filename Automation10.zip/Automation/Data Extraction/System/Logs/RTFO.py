import pyautogui
import time
import pygetwindow as gw
import logging
from datetime import datetime
import pywinauto
from pywinauto.application import Application
from pywinauto import mouse, keyboard

# Configure logging
logging.basicConfig(filename="../Bin/Temp/Report_Automation.log", level=logging.INFO,
                    format="%(asctime)s - %(message)s")


def list_all_window_titles():
    """List all current window titles for debugging."""
    try:
        windows = gw.getWindowsWithTitle("")
        for window in windows:
            logging.info("Window found: " + window.title)
            print(f"Window title found: {window.title}")
    except Exception as e:
        logging.error(f"Error listing window titles: {str(e)}")


def get_window_by_title(title):
    """Get window object by partial, case-insensitive title match."""
    try:
        windows = gw.getWindowsWithTitle("")
        for window in windows:
            if title.lower() in window.title.lower():
                logging.info(f"Match found: {window.title}")
                return window
    except Exception as e:
        logging.error(f"Error finding window: {str(e)}")
    return None


def wait_for_window(title, timeout=100):
    """
    Wait for a window with the specified title to appear and become responsive,
    with a maximum timeout of 100 seconds.
    Returns the window object or None if timeout.
    """
    start_time = time.time()
    logging.info(f"Waiting for window with title containing '{title}'...")

    while time.time() - start_time < timeout:
        window = get_window_by_title(title)
        if window:
            # Window exists, now check if it's responsive
            try:
                # Try to get properties to see if the window is responsive
                window_info = f"Window: {window.title}, Size: {window.width}x{window.height}, Position: ({window.left},{window.top})"
                logging.info(f"Found window: {window_info}")

                # Try to bring window to foreground as a responsive test
                window.activate()
                time.sleep(0.5)

                # If we've reached here without exception, window should be responsive
                logging.info(f"Window is responsive: {window.title}")
                return window
            except Exception as e:
                logging.info(f"Window found but not yet responsive: {str(e)}")
                # Window exists but may not be fully loaded, wait a bit longer
                time.sleep(1)
        else:
            # Window hasn't appeared yet
            elapsed = time.time() - start_time
            if elapsed % 10 < 0.5:  # Log only approximately every 10 seconds
                logging.info(f"Waiting for '{title}' window... ({int(elapsed)}/{timeout}s)")
            time.sleep(0.5)

    # If we get here, we've timed out
    logging.error(f"Timeout of {timeout}s reached waiting for window with title '{title}'")
    return None


def is_window_responsive(window):
    """Check if a window is responsive by trying to access its properties."""
    try:
        # Try accessing properties that might fail if window is not responsive
        _ = window.title
        _ = window.width
        _ = window.height
        _ = window.left
        _ = window.top
        return True
    except Exception:
        return False


def wait_for_window_to_stabilize(window, timeout=100):
    """Wait for a window's position and size to stabilize, indicating it's fully loaded."""
    if not window:
        return False

    start_time = time.time()
    previous_properties = None
    stable_count = 0
    required_stable_checks = 3  # Number of consecutive stable checks required

    while time.time() - start_time < timeout:
        try:
            current_properties = (window.left, window.top, window.width, window.height)

            if previous_properties == current_properties:
                stable_count += 1
                if stable_count >= required_stable_checks:
                    logging.info(f"Window has stabilized: {window.title}")
                    return True
            else:
                stable_count = 0
                previous_properties = current_properties

            time.sleep(0.5)
        except Exception as e:
            logging.warning(f"Error checking window stability: {str(e)}")
            time.sleep(1)

    logging.error(f"Timeout waiting for window to stabilize: {window.title}")
    return False


def click_parameters(report_name, max_wait_time=100):
    """Handle the report window, click Parameters, and handle the workflow with dynamic waiting."""
    try:
        # Type the report name and press enter to open the report
        pyautogui.press('tab')
        pyautogui.hotkey('shift', 'tab')
        pyautogui.press('backspace')
        pyautogui.write(report_name)
        pyautogui.press('enter')
        logging.info(f"Entered report name: {report_name}")
        time.sleep(1)
        pyautogui.doubleClick(x=1071, y=194)

        # (Optional) Debugging: List all open windows
        list_all_window_titles()

        # Wait for and get the report window with dynamic waiting
        logging.info(f"Waiting for initial report window: {report_name}")
        start_wait = time.time()
        report_window = wait_for_window(report_name, max_wait_time)
        if not report_window:
            logging.error(
                f"Report window with title containing '{report_name}' did not appear within {max_wait_time} seconds")
            print(
                f"Error: Report window with title containing '{report_name}' did not appear within {max_wait_time} seconds")
            return False

        # Wait for window to be fully loaded and stable
        if not wait_for_window_to_stabilize(report_window, max_wait_time):
            logging.error(f"Report window did not stabilize within {max_wait_time} seconds")
            print(f"Error: Report window did not stabilize within {max_wait_time} seconds")
            return False

        # Activate the report window and click Parameters
        try:
            report_window.activate()
            time.sleep(0.5)  # Short wait after activation

            parameters_x_offset = 300
            parameters_y_offset = 80

            win_left = report_window.left
            win_top = report_window.top
            parameters_x = win_left + parameters_x_offset
            parameters_y = win_top + parameters_y_offset

            pyautogui.moveTo(parameters_x, parameters_y)
            time.sleep(0.5)
            pyautogui.doubleClick()
            pyautogui.press('backspace')
            pyautogui.write('011124')
            pyautogui.press('tab')
            pyautogui.write('300425')
            pyautogui.press('enter')
            logging.info("Submitted parameters on the first report window.")

        except Exception as e:
            logging.error(f"Error clicking Parameters on initial report window: {str(e)}")
            print(f"Error clicking Parameters on initial report window: {str(e)}")
            return False

        # Wait for the new report window to appear after parameter submission with dynamic waiting
        logging.info("Waiting for new report window after parameter submission...")
        new_report_window = wait_for_window(report_name, max_wait_time)
        if not new_report_window:
            logging.error(
                f"New report window with title containing '{report_name}' did not appear within {max_wait_time} seconds")
            print(
                f"Error: New report window with title containing '{report_name}' did not appear within {max_wait_time} seconds")
            return False

        # Wait for new window to be fully loaded and stable
        if not wait_for_window_to_stabilize(new_report_window, max_wait_time):
            logging.error(f"New report window did not stabilize within {max_wait_time} seconds")
            print(f"Error: New report window did not stabilize within {max_wait_time} seconds")
            return False

        logging.info(f"New report window found and stable: {new_report_window.title}")

        # Activate the new report window and click Parameters
        try:
            new_report_window.activate()
            time.sleep(5)  # Short wait after activation

            new_parameters_x_offset = 14
            new_parameters_y_offset = 37

            new_win_left = new_report_window.left
            new_win_top = new_report_window.top
            new_parameters_x = new_win_left + new_parameters_x_offset
            new_parameters_y = new_win_top + new_parameters_y_offset

            pyautogui.moveTo(new_parameters_x, new_parameters_y)
            time.sleep(5)
            pyautogui.doubleClick()
            logging.info("Clicked Parameters on new report window using new offsets.")
        except Exception as e:
            logging.error(f"Error clicking Parameters on new report window: {str(e)}")
            print(f"Error clicking Parameters on new report window: {str(e)}")
            return False

        return True

    except Exception as e:
        logging.error(f"Error in click_parameters: {str(e)}")
        print(f"Error: {str(e)}")
        return False


def manipulate_export_window(filename="HRG_Report_W24-25", save_path="D:\\Daily_Chart\\Chart_Resources\\S25\\HRG"):
    """
    Detect and manipulate the Export Report window to:
    1. Set the address bar to the specified path
    2. Set the filename
    3. Select the file format from dropdown
    4. Click Save
    """
    try:
        # Connect to the existing window
        app = Application(backend="win32").connect(title_re="Export Report")

        # Get the dialog window
        dialog = app.window(title="Export Report")
        print("Found Export Report window")
        logging.info("Found Export Report window")

        # Ensure the window is active
        if not dialog.has_focus():
            dialog.set_focus()
            time.sleep(0.5)

        # ===== ADDRESS BAR HANDLING =====
        print("Attempting to access address bar...")
        logging.info("Attempting to access address bar...")
        keyboard.send_keys("%d")  # Alt+D is the standard shortcut for address bar
        time.sleep(0.5)

        # Clear existing content and type new path
        keyboard.send_keys("^a")  # Ctrl+A to select all text
        time.sleep(0.2)
        keyboard.send_keys(save_path)  # Type the new path
        time.sleep(0.2)
        keyboard.send_keys("{ENTER}")  # Press Enter to navigate
        print(f"Attempted to set address path to: {save_path}")
        logging.info(f"Attempted to set address path to: {save_path}")
        time.sleep(1.5)  # Wait longer for navigation to complete

        # ===== FILENAME HANDLING =====
        # Fill in the filename field
        filename_edit = dialog["Edit"]
        filename_edit.set_text(filename)
        print(f"Set filename to: {filename}")
        logging.info(f"Set filename to: {filename}")

        # Get the position of the filename field to use as reference
        filename_rect = filename_edit.rectangle()

        # Calculate position for clicking the dropdown
        # The dropdown is beneath the filename field, so we'll click below it
        dropdown_x = filename_rect.left + (filename_rect.width() // 2)  # Center horizontally
        dropdown_y = filename_rect.bottom + 25  # 25 pixels below the filename field

        # Click to activate the dropdown
        mouse.click(button='left', coords=(dropdown_x, dropdown_y))
        print(f"Clicked at coordinates ({dropdown_x}, {dropdown_y}) to activate dropdown")
        logging.info(f"Clicked at coordinates ({dropdown_x}, {dropdown_y}) to activate dropdown")
        time.sleep(1)  # Give it time to open

        # Now select the 4th item by clicking at an estimated position
        # Each item is typically around 20-25 pixels tall
        item_height = 20  # Approximate height of each dropdown item
        fourth_item_y = dropdown_y + (item_height * 3)  # 0-based index, so 3 for 4th item

        # Click on the 4th item
        mouse.click(button='left', coords=(dropdown_x, fourth_item_y))
        print(f"Clicked 4th item at coordinates ({dropdown_x}, {fourth_item_y})")
        logging.info(f"Clicked 4th item at coordinates ({dropdown_x}, {fourth_item_y})")
        time.sleep(0.5)

        # Find and click the Save button more accurately
        # First try to find it properly by name
        try:
            # Get all buttons in the dialog
            buttons = dialog.children(control_type="Button")
            save_button = None

            # Print available buttons for debugging
            print("Available buttons:")
            logging.info("Available buttons:")
            for button in buttons:
                print(f"- {button.window_text()}")
                logging.info(f"- {button.window_text()}")
                if button.window_text() == "Save":
                    save_button = button

            if save_button:
                # Get the center of the Save button
                save_rect = save_button.rectangle()
                save_center_x = save_rect.left + (save_rect.width() // 2)
                save_center_y = save_rect.top + (save_rect.height() // 2)

                # Click exactly in the center of the Save button
                mouse.click(button='left', coords=(save_center_x, save_center_y))
                print(f"Clicked Save button at center: ({save_center_x}, {save_center_y})")
                logging.info(f"Clicked Save button at center: ({save_center_x}, {save_center_y})")
            else:
                # Backup approach: use dialog dimensions to estimate Save button position
                # Save is typically the left button in the bottom right corner
                dialog_rect = dialog.rectangle()

                # Calculate the Save button position more precisely
                # Assuming Save is to the left of Cancel, and both are in the bottom right
                save_button_x = dialog_rect.right - 160  # Further left than previous estimate
                save_button_y = dialog_rect.bottom - 30  # Close to bottom

                mouse.click(button='left', coords=(save_button_x, save_button_y))
                print(f"Clicked Save button at estimated position: ({save_button_x}, {save_button_y})")
                logging.info(f"Clicked Save button at estimated position: ({save_button_x}, {save_button_y})")

        except Exception as e:
            print(f"Error with button interaction: {e}")
            logging.error(f"Error with button interaction: {e}")
            # Last resort: use keyboard navigation
            print("Using keyboard navigation to select Save button")
            logging.info("Using keyboard navigation to select Save button")
            # Press Shift+Tab to go back to Cancel, then Tab to go to Save, then Enter
            keyboard.send_keys("{TAB}{ENTER}")
            print("Used keyboard navigation to click Save")
            logging.info("Used keyboard navigation to click Save")

        return True

    except Exception as e:
        print(f"Error in manipulate_export_window: {e}")
        logging.error(f"Error in manipulate_export_window: {e}")
        return False


def initiate_export(report_window):
    """Initiate the export process by clicking on the export button"""
    try:
        # Ensure the report window is active
        report_window.activate()
        time.sleep(1)

        # Calculate position for the export button (adjust these coordinates based on your application)
        export_x_offset = 30  # Example offset, adjust as needed
        export_y_offset = 37  # Example offset, adjust as needed

        export_x = report_window.left + export_x_offset
        export_y = report_window.top + export_y_offset

        # Click the export button
        pyautogui.moveTo(export_x, export_y)
        time.sleep(0.5)
        pyautogui.click()
        logging.info("Clicked export button")
        print("Clicked export button")

        # Wait for export dialog to appear
        time.sleep(3)  # Adjust wait time as needed

        return True
    except Exception as e:
        logging.error(f"Error initiating export: {str(e)}")
        print(f"Error initiating export: {str(e)}")
        return False


def close_report_window(report_name, max_wait_time=100):
    """
    Refocus on the report window after export is complete and close it with ESC key
    until the window no longer exists.
    """
    try:
        logging.info(f"Waiting for report window to refocus after export: {report_name}")
        print(f"Waiting for report window to refocus after export: {report_name}")

        # Wait a moment for any potential "Save Complete" dialog to finish
        time.sleep(3)

        # Find and get the report window
        report_window = wait_for_window(report_name, max_wait_time)
        if not report_window:
            logging.error(f"Could not find report window to close: {report_name}")
            print(f"Could not find report window to close: {report_name}")
            return False

        # Make sure the window is responsive before sending ESC
        if not wait_for_window_to_stabilize(report_window, max_wait_time):
            logging.error(f"Report window not responsive for closing: {report_name}")
            print(f"Report window not responsive for closing: {report_name}")
            return False

        # Activate the window and start sending ESC keys
        report_window.activate()
        time.sleep(1)  # Give it time to come to foreground

        # Press ESC until the window disappears
        max_esc_presses = 10  # Safety limit
        esc_count = 0

        while esc_count < max_esc_presses:
            # Check if window still exists
            if not get_window_by_title(report_name):
                logging.info(f"Report window successfully closed after {esc_count} ESC presses")
                print(f"Report window successfully closed after {esc_count} ESC presses")
                return True

            # Send ESC key
            pyautogui.press('escape')
            logging.info(f"Pressed ESC key ({esc_count + 1}/{max_esc_presses})")
            print(f"Pressed ESC key ({esc_count + 1}/{max_esc_presses})")
            esc_count += 1

            # Wait a moment to see if window closes
            time.sleep(1)

        # If we get here, we've reached max ESC presses
        if get_window_by_title(report_name):
            logging.warning(f"Report window still exists after {max_esc_presses} ESC presses")
            print(f"Warning: Report window still exists after {max_esc_presses} ESC presses")
            return False
        else:
            logging.info("Report window closed successfully")
            print("Report window closed successfully")
            return True

    except Exception as e:
        logging.error(f"Error closing report window: {str(e)}")
        print(f"Error closing report window: {str(e)}")
        return False


def run_full_automation():
    """Run the complete automation process from report opening to export and close"""
    try:
        print(f"Starting full report automation at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}...")
        logging.info(f"Starting full report automation at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}...")

        # Configuration variables
        report_name = "Forecast - Occupancy/Availability per Room Type"
        max_wait_time = 100  # Maximum wait time in seconds
        export_filename = "RoomType Forecast Occupancy"
        export_path = "D:\\Daily_Chart\\Chart_Resources\\S25\\HRG"

        # Step 1: Open and set up the report
        if not click_parameters(report_name, max_wait_time):
            logging.error("Failed to complete report parameter setup")
            print("Failed to complete report parameter setup")
            return False

        print("Successfully configured report parameters")
        logging.info("Successfully configured report parameters")

        # Wait for the report to fully load after parameter configuration
        time.sleep(10)  # Adjust wait time as needed

        # Step 2: Get the report window for export
        report_window = get_window_by_title(report_name)
        if not report_window:
            logging.error("Could not find report window for export")
            print("Could not find report window for export")
            return False

        # Step 3: Initiate the export process
        if not initiate_export(report_window):
            logging.error("Failed to initiate export process")
            print("Failed to initiate export process")
            return False

        # Step 4: Handle the export window
        if not manipulate_export_window(export_filename, export_path):
            logging.error("Failed to complete export process")
            print("Failed to complete export process")
            return False

        # Step 5: Refocus on report window and close it with ESC
        if not close_report_window(report_name, max_wait_time):
            logging.warning("Issue while closing report window")
            print("Warning: Issue while closing report window")
            # Continue anyway since export might have succeeded

        print("Successfully completed full report automation")
        logging.info("Successfully completed full report automation")
        return True

    except Exception as e:
        logging.error(f"Error in full automation process: {str(e)}")
        print(f"Error in full automation process: {str(e)}")
        return False


if __name__ == "__main__":
    try:
        # Run the full automation
        run_full_automation()
    except Exception as e:
        print(f"Main execution error: {str(e)}")
        logging.error(f"Main execution error: {str(e)}")