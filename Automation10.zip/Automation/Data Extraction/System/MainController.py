import os
import sys
import subprocess
import logging
import psutil
from pathlib import Path
from datetime import datetime
import json
import time


class MainController:
    def __init__(self):
        self.system_path = Path(__file__).parent
        self.setup_logging()
        self.bin_path = self.system_path / "Bin"
        self.main_scripts = self.find_main_scripts()  # dict: {folder_name: Main.py path}
        self.running_processes = {}

        # Script map per hotel (only .py files now)
        self.script_file_map_per_hotel = {
            "White Beach": [
                "C.RTA.py",
                "D.RTO.py",
                "E.RCT.py",
                "E.RCR.py",
                "F.AR.py",
                "C.RM.py",
                "C.RC.py",
                "H&F.py",
                "CF.py"
            ]
            # Add more hotels as needed
        }

    def setup_logging(self):
        logs_dir = self.system_path / "Logs"
        logs_dir.mkdir(exist_ok=True)
        log_file = logs_dir / f"controller_{datetime.now().strftime('%Y%m%d')}.log"
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler()
            ]
        )

    def find_main_scripts(self):
        """Find all Main.py scripts in hotel directories"""
        scripts = {}
        for path in self.bin_path.glob("*/Main.py"):
            if path.parent.name != "Temp":
                hotel_folder_name = path.parent.name  # Keep full name like "1.Dana Beach"
                scripts[hotel_folder_name] = path
        return scripts

    def list_hotels(self):
        """Return a list of all hotel folder names"""
        return list(self.main_scripts.keys())

    def create_config_file(self, hotel_folder_name):
        """Create a config.json file in the hotel folder"""
        script_path = self.main_scripts[hotel_folder_name]
        hotel_path = script_path.parent
        hotel_display_name = hotel_folder_name.lstrip("0123456789.").strip()

        config_path = hotel_path / "config.json"

        config_data = {
            "username": "a.ibrahim",
            "password": "Des101",
            "start_date": datetime.now().strftime('%d%m%y'),
            "end_date": (datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)).strftime('%d%m%y'),
            "scripts_to_run": self.script_file_map_per_hotel.get(hotel_display_name, [])
        }

        hotel_path.mkdir(parents=True, exist_ok=True)
        with open(config_path, "w") as f:
            json.dump(config_data, f, indent=4)
        logging.info(f"Config file created for {hotel_display_name} at {config_path}")

    def run_hotel_script(self, hotel_folder_name):
        """Run a specific hotel's Main.py script"""
        if hotel_folder_name not in self.main_scripts:
            logging.error(f"Hotel '{hotel_folder_name}' not found")
            return False

        self.create_config_file(hotel_folder_name)
        script_path = self.main_scripts[hotel_folder_name]

        try:
            logging.info(f"Starting automation for {hotel_folder_name}")
            process = subprocess.Popen(
                [sys.executable, str(script_path)],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            self.running_processes[hotel_folder_name] = process
            stdout, stderr = process.communicate()

            if process.returncode == 0:
                logging.info(f"Successfully completed automation for {hotel_folder_name}")
                return True
            else:
                logging.error(f"Failed automation for {hotel_folder_name}")
                logging.error(f"Error output: {stderr}")
                return False

        except Exception as e:
            logging.error(f"Error running automation for {hotel_folder_name}: {str(e)}")
            return False
        finally:
            if hotel_folder_name in self.running_processes:
                del self.running_processes[hotel_folder_name]

    def run_all_hotels(self, delay_between=5):
        """Run all hotel scripts one after another"""
        for hotel_folder in self.main_scripts.keys():
            success = self.run_hotel_script(hotel_folder)
            if success:
                logging.info(f"Completed automation for {hotel_folder}")
            else:
                logging.error(f"Failed automation for {hotel_folder}")
            time.sleep(delay_between)

    def stop_hotel_script(self, hotel_folder_name):
        if hotel_folder_name in self.running_processes:
            process = self.running_processes[hotel_folder_name]
            try:
                process.terminate()
                process.wait(timeout=5)
                logging.info(f"Stopped automation for {hotel_folder_name}")
                return True
            except subprocess.TimeoutExpired:
                process.kill()
                logging.warning(f"Force killed automation for {hotel_folder_name}")
                return True
            finally:
                del self.running_processes[hotel_folder_name]
        return False

    def stop_all_scripts(self):
        for hotel_folder_name in list(self.running_processes.keys()):
            self.stop_hotel_script(hotel_folder_name)

    def get_running_hotels(self):
        return list(self.running_processes.keys())

    def check_fidelio_running(self):
        for proc in psutil.process_iter(['name']):
            if proc.info['name'] and proc.info['name'].lower() == 'fideliov8.exe':
                return True
        return False


if __name__ == "__main__":
    controller = MainController()
    print("Available hotels:", controller.list_hotels())
    controller.run_all_hotels()
